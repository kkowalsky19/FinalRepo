//
//  ViewController.swift
//  BK-Test
//
//  Created by Joseph Albert on 4/2/21.
//  Copyright © 2021 Joseph Albert. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    @IBOutlet var videoPreview: UIView!
    var stringURL = String()
    enum error: Error {
        case noCameraAvailable
        case videoInputFailed
    }
    
    
    
    private let imageView: UIImageView = {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 500, height: 500) )
        imageView.image = UIImage(named: "Image-5")
        return imageView
    }()
    
    @IBOutlet weak var QRView: UIView!
    @IBOutlet weak var codeView: UILabel!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var codeStatus: UILabel!
    
    
    
    
    
    
    @IBAction func keypad0(_ sender: Any) {
        if(codeView.text!.count > 5){
            print("its too damn long")
        }else{
            codeView.text = codeView.text! + "0"
        }
    }
    @IBAction func keypad1(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "1"
        }
    }
    @IBAction func keypad2(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "2"
        }
    }
    @IBAction func keypad3(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "3"
        }
    }
    @IBAction func keypad4(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "4"
        }
    }
    @IBAction func keypad5(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "5"
        }
    }
    @IBAction func keypad6(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "6"
        }
    }
    @IBAction func keypad7(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "7"
        }
    }
    @IBAction func keypad8(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "8"
        }
    }
    @IBAction func keypad9(_ sender: Any) {
        if(codeView.text!.count > 5){
                   print("its too damn long")
               }else{
        codeView.text = codeView.text! + "9"
        }
    }
    @IBAction func clearText(_ sender: Any) {
        codeView.text = ""
    }
    
    
     
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemBackground
        // Do any additional setup after loading the view.
       // self.codeView.isHidden = true
        mainView.isHidden = true
        view.addSubview(imageView)
        
        codeView.text = ""
        
        do {
            
            
            
            
        } catch {
            print("failed to scan QR code")
        }
        
    }
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects:[Any]!, from connection: AVCaptureConnection!){
        if metadataObjects.count > 0 {
            let machineReadableCode = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
            if machineReadableCode.type == AVMetadataObject.ObjectType.qr {
                stringURL = machineReadableCode.stringValue!
                print("FOUND A STRING BELOW***")
                print(stringURL)
                //stringURL = QR value

            }
        }
    }
    
    func scanQRCode() throws{
        let avCaptureSession = AVCaptureSession()
        
        guard let avCaptureDevice = AVCaptureDevice.default(for: AVMediaType.video) else {
            print("No camera found")
            throw error.noCameraAvailable
        }
        
        guard let avCaptureInput = try? AVCaptureDeviceInput(device: avCaptureDevice) else{
            print("Failed to init camera")
            throw error.videoInputFailed
            
        }
        
        let avCaptureMetadataOutput = AVCaptureMetadataOutput()
        avCaptureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        avCaptureSession.addInput(avCaptureInput)
        avCaptureSession.addOutput(avCaptureMetadataOutput)
        
        avCaptureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        let avCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: avCaptureSession)
        
        avCaptureVideoPreviewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        
        avCaptureVideoPreviewLayer.frame = videoPreview.bounds
        self.videoPreview.layer.addSublayer(avCaptureVideoPreviewLayer)
        avCaptureSession.startRunning()
    }
    
    
    var refundNeeded = false
    
    @IBAction func submitCode(_ sender: Any) {
           let session = URLSession.shared
           let url = "https://beer-kiosk.com/ipadServer.php?code="+codeView.text!
           self.codeStatus.text = "Checking Code..."
                   let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
                   request.httpMethod = "POST"
                   request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                   var params :[String: Any]?
                   params = ["checkCode" : "0000"]
                   do{
                    request.httpBody = try JSONSerialization.data(withJSONObject: params!, options: JSONSerialization.WritingOptions())

                       let task = session.dataTask(with: request as URLRequest as URLRequest, completionHandler: {(data, response, error) in
                           if let response = response {
                               let nsHTTPResponse = response as! HTTPURLResponse
                               let statusCode = nsHTTPResponse.statusCode
                               print ("status code = \(statusCode)")
                           }
                           if let error = error {
                               print ("\(error)")
                           }
                           if let data = data {
                               do{
                                   let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions())
                                   print ("data = \(jsonResponse)")
                                   let responseData = "data = \(jsonResponse)"
                                   //TAKES SO LONG BECAUSE OF SOMETHING IN NEXT FEW LINES
                                   if(responseData.contains("Error")){
                                    DispatchQueue.main.async {
                                        self.codeView.text = ""
                                        self.codeStatus.text = "Invalid Code"
                                        
//                                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                                        let vc = storyboard.instantiateViewController(withIdentifier: "pourBeerController")
//                                        self.navigationController!.present(vc, animated: true, completion: nil)
                                    }
                                   }
                                   else{
                                        DispatchQueue.main.async {
                                            self.codeView.text = ""
                                            self.codeStatus.text = "Valid Code"
                                        }
                                        //valid code has been entered. contact particle
                                        if ParticleCloud.sharedInstance().injectSessionAccessToken("3971d20aad303ad62d941f4f0c16fe69302ba5cd") {
                                            print("Session is active")
                                        } else {
                                           print("Bad access token provided")
                                        }
                                    
                                    
                                        //START PARTICLE
                                        var myPhoton : ParticleDevice?
                                        ParticleCloud.sharedInstance().getDevices { (devices:[ParticleDevice]?, error:Error?) -> Void in
                                            if let _ = error {
                                                print("Check your internet connectivity")
                                            }
                                            else {
                                                if let d = devices {
                                                    for device in d {
                                                        if device.name == "BKMardi" {
                                                            print("device found")
                                                            myPhoton = device
                                                           
                                                            let funcArgs = ["true"]
                                                            var task = myPhoton!.callFunction("pourDrink", withArguments: funcArgs) { (resultCode : NSNumber?, error : Error?) -> Void in
                                                               if (error == nil) {
                                                                   print("Attempting pour ..")
                                                               }
                                                           }
                                                           var bytesToReceive : Int64 = task.countOfBytesExpectedToReceive
                                                            
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            var handler : Any?
                                            handler = ParticleCloud.sharedInstance().subscribeToAllEvents(withPrefix: "Dispensed", handler: { (event :ParticleEvent?, error : Error?) in
                                                if let _ = error {
                                                    print ("could not subscribe to events")
                                                } else {
                                                    DispatchQueue.main.async(execute: {
                                                        print("got event with data \(event?.data)")
                                                        //true : beer was poured, false: issue occured
                                                        if(event?.data == "false"){
                                                            self.refundNeeded = true
                                                        }
                                                    
                                                    })
                                                }
                                            })
                                            
                                            
                                        }
                                        //END PARTICLE
                                    DispatchQueue.main.async {
                                        self.codeStatus.text = ""
                                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                        let vc = storyboard.instantiateViewController(withIdentifier: "pourBeerController")
                                        self.navigationController!.present(vc, animated: true, completion: nil)
                                        
                                    }
                                    
                            
                                    
                                    sleep(6) //sleep while drink pour animation occurs
                                    
                                    if(self.refundNeeded == true){
                                        self.refundNeeded = false
                                        print("refund requested")
                                        
                                        //refund view
                                        DispatchQueue.main.async {
                                            self.codeStatus.text = ""
                                            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                            let vc = storyboard.instantiateViewController(withIdentifier: "refundController")
                                            self.navigationController!.present(vc, animated: true, completion: nil)
                                            //self.presentingViewController?.dismiss(animated: true, completion: nil)
                                            
                                        }
                                        //end refund view
                                        
                                        //ISSUE REFUND HERE:
                                        
                                        
                                    }else{
                                        print("Pour successful")
                                    }
                                    

                                   }
                               }catch _ {
                                   print ("Oops not good JSON formatted response")
                               }
                           }
                       })
                       task.resume()
                   }catch _ {
                       print ("Oops something happened buddy")
                   }
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.center = view.center
        DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
            self.animate()
        })
    }
    

    private func animate() {
        UIView.animate(withDuration: 2, animations: {
            let size = self.view.frame.size.width * 3
            let diffx = size - self.view.frame.size.width
            let diffy = self.view.frame.size.height - size
                        
            self.imageView.frame = CGRect(
                x: -diffx/2,
                y: diffy/2,
                width: size,
                height: size)
        })
        
        UIView.animate(withDuration: 2, animations: {
            self.imageView.alpha = 0
        }, completion: { done in
            if done {
        
                
                
                DispatchQueue.main.asyncAfter(deadline: .now()+1.5, execute: {
                    self.mainView.isHidden = false
                })
            }
        })
    
    }
}

