//
//  AnimatedViewController.swift
//  BK-Test
//
//  Created by Joseph Albert on 4/2/21.
//  Copyright © 2021 Joseph Albert. All rights reserved.
//

import UIKit

class AnimatedViewController: UIViewController {
    
    @IBOutlet weak var progressView: UIProgressView!
    var timer = Timer()
    var progress: Float = 0.001
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemBackground
        progressView.progress = progress
        
        //change speed of loading bar
        timer = Timer.scheduledTimer(withTimeInterval: 0.055, repeats: true, block: { (timer) in
        //6.5 seconds - timer = Timer.scheduledTimer(withTimeInterval: 0.065, repeats: true, block: { (timer) in
            self.progress += 0.01
            self.progressView.progress = self.progress
            
            if(self.progressView.progress == 1){
                self.progressView.progress = 0.0
                self.presentingViewController?.dismiss(animated: true, completion: nil)
                timer.invalidate()
            }
        })
        
        
        
    }
   
    
    

}
