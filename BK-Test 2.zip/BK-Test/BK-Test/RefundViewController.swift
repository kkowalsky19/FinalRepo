//
//  RefundViewController.swift
//  BK-Test
//
//  Created by Joseph Albert on 5/4/21.
//  Copyright © 2021 Joseph Albert. All rights reserved.
//

import UIKit

class RefundViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //sleep(5)
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            // Do whatever you want
//            print("dismissing refund view now")
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let vc = storyboard.instantiateViewController(withIdentifier: "refundController")
//            vc.dismiss(animated:true, completion: nil)
            self.presentingViewController?.dismiss(animated: true, completion: nil)
        }


        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
